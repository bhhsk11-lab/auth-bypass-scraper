"""Auth-bypass scraping engine."""
